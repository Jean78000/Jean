<?php

namespace App\Repository;

use App\Entity\ContactCommerciaux;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method ContactCommerciaux|null find($id, $lockMode = null, $lockVersion = null)
 * @method ContactCommerciaux|null findOneBy(array $criteria, array $orderBy = null)
 * @method ContactCommerciaux[]    findAll()
 * @method ContactCommerciaux[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ContactCommerciauxRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ContactCommerciaux::class);
    }

    // /**
    //  * @return ContactCommerciaux[] Returns an array of ContactCommerciaux objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?ContactCommerciaux
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
