<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ProduitRepository")
 */
class Produit
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $produit_nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $product_owner;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $filiere;

    /**
     * @ORM\Column(type="datetime")
     */
    private $date_fin_support;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $fournisseur;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $version;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\ExpireAssets", inversedBy="produits")
     */
    private $produit_relation;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\ContactCommerciaux", mappedBy="contact_commerciaux_relation")
     */
    private $contactCommerciauxes;

    public function __construct()
    {
        $this->produit_relation = new ArrayCollection();
        $this->contactCommerciauxes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getProduitNom(): ?string
    {
        return $this->produit_nom;
    }

    public function setProduitNom(string $produit_nom): self
    {
        $this->produit_nom = $produit_nom;

        return $this;
    }

    public function getProductOwner(): ?string
    {
        return $this->product_owner;
    }

    public function setProductOwner(string $product_owner): self
    {
        $this->product_owner = $product_owner;

        return $this;
    }

    public function getFiliere(): ?string
    {
        return $this->filiere;
    }

    public function setFiliere(string $filiere): self
    {
        $this->filiere = $filiere;

        return $this;
    }

    public function getDateFinSupport(): ?\DateTimeInterface
    {
        return $this->date_fin_support;
    }

    public function setDateFinSupport(\DateTimeInterface $date_fin_support): self
    {
        $this->date_fin_support = $date_fin_support;

        return $this;
    }

    public function getFournisseur(): ?string
    {
        return $this->fournisseur;
    }

    public function setFournisseur(string $fournisseur): self
    {
        $this->fournisseur = $fournisseur;

        return $this;
    }

    public function getVersion(): ?string
    {
        return $this->version;
    }

    public function setVersion(string $version): self
    {
        $this->version = $version;

        return $this;
    }

    /**
     * @return Collection|ExpireAssets[]
     */
    public function getProduitRelation(): Collection
    {
        return $this->produit_relation;
    }

    public function addProduitRelation(ExpireAssets $produitRelation): self
    {
        if (!$this->produit_relation->contains($produitRelation)) {
            $this->produit_relation[] = $produitRelation;
        }

        return $this;
    }

    public function removeProduitRelation(ExpireAssets $produitRelation): self
    {
        if ($this->produit_relation->contains($produitRelation)) {
            $this->produit_relation->removeElement($produitRelation);
        }

        return $this;
    }

    /**
     * @return Collection|ContactCommerciaux[]
     */
    public function getContactCommerciauxes(): Collection
    {
        return $this->contactCommerciauxes;
    }

    public function addContactCommerciaux(ContactCommerciaux $contactCommerciaux): self
    {
        if (!$this->contactCommerciauxes->contains($contactCommerciaux)) {
            $this->contactCommerciauxes[] = $contactCommerciaux;
            $contactCommerciaux->setContactCommerciauxRelation($this);
        }

        return $this;
    }

    public function removeContactCommerciaux(ContactCommerciaux $contactCommerciaux): self
    {
        if ($this->contactCommerciauxes->contains($contactCommerciaux)) {
            $this->contactCommerciauxes->removeElement($contactCommerciaux);
            // set the owning side to null (unless already changed)
            if ($contactCommerciaux->getContactCommerciauxRelation() === $this) {
                $contactCommerciaux->setContactCommerciauxRelation(null);
            }
        }

        return $this;
    }
}
