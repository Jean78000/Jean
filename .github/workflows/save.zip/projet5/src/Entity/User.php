<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\UserRepository")
 */
class User
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $badge;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $prenom;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\ExpireAssets", inversedBy="users")
     */
    private $user_Relation;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\RoleUser", inversedBy="role_user_relation")
     * @ORM\JoinColumn(nullable=false)
     */
    private $roleUser;

    public function __construct()
    {
        $this->user_Relation = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getBadge(): ?string
    {
        return $this->badge;
    }

    public function setBadge(string $badge): self
    {
        $this->badge = $badge;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * @return Collection|ExpireAssets[]
     */
    public function getUserRelation(): Collection
    {
        return $this->user_Relation;
    }

    public function addUserRelation(ExpireAssets $userRelation): self
    {
        if (!$this->user_Relation->contains($userRelation)) {
            $this->user_Relation[] = $userRelation;
        }

        return $this;
    }

    public function removeUserRelation(ExpireAssets $userRelation): self
    {
        if ($this->user_Relation->contains($userRelation)) {
            $this->user_Relation->removeElement($userRelation);
        }

        return $this;
    }

    public function getRoleUser(): ?RoleUser
    {
        return $this->roleUser;
    }

    public function setRoleUser(?RoleUser $roleUser): self
    {
        $this->roleUser = $roleUser;

        return $this;
    }
}
