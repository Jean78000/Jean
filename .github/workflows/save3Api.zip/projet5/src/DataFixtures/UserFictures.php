<?php

namespace App\DataFixtures;

use App\Entity\User;
use App\Entity\RoleUser;
use Doctrine\Persistence\ObjectManager;
use Doctrine\Bundle\FixturesBundle\Fixture;

class UserFictures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $r1 = new RoleUser();
        $r1->setStrRole("admin");

        $manager->persist($r1);

        $r2 = new RoleUser();
        $r2->setStrRole("user");

        $manager->persist($r2);


        $u1 = new User();
        $u1->setBadge("S111111")
           ->setNom("Martin")
           ->setPrenom("Louis")
           ->setRoleUser($r1)
           ;
        $manager->persist($u1);

        $u2 = new User();
        $u2->setBadge("S222222")
           ->setNom("Therese")
           ->setPrenom("Marie")
           ->setRoleUser($r2);
        $manager->persist($u2);

        $u3 = new User();
        $u3->setBadge("S333333")
           ->setNom("Brown")
           ->setPrenom("Alphonse")
           ->setRoleUser($r2);
        $manager->persist($u3);

        $u4 = new User();
        $u4->setBadge("S444444")
           ->setNom("Paul")
           ->setPrenom("Jean")
           ->setRoleUser($r2);
        $manager->persist($u4);

        $u5 = new User();
        $u5->setBadge("S555555")
           ->setNom("Bond")
           ->setPrenom("James")
           ->setRoleUser($r2);
        $manager->persist($u5);

        $manager->flush();
    }
}
