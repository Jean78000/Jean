<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ContactCommerciauxRepository")
 */
class ContactCommerciaux
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $prenom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $mail;

    /**
     * @ORM\Column(type="integer")
     */
    private $telephonne;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Produit", inversedBy="contactCommerciauxes")
     */
    private $contact_commerciaux_relation;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getMail(): ?string
    {
        return $this->mail;
    }

    public function setMail(string $mail): self
    {
        $this->mail = $mail;

        return $this;
    }

    public function getTelephonne(): ?int
    {
        return $this->telephonne;
    }

    public function setTelephonne(int $telephonne): self
    {
        $this->telephonne = $telephonne;

        return $this;
    }

    public function getContactCommerciauxRelation(): ?Produit
    {
        return $this->contact_commerciaux_relation;
    }

    public function setContactCommerciauxRelation(?Produit $contact_commerciaux_relation): self
    {
        $this->contact_commerciaux_relation = $contact_commerciaux_relation;

        return $this;
    }
}
