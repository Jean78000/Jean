<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\HistoriqueRepository")
 */
class Historique
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $id_prev;

    /**
     * @ORM\OneToOne(targetEntity="App\Entity\ExpireAssets", cascade={"persist", "remove"})
     */
    private $historique_relation;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getIdPrev(): ?int
    {
        return $this->id_prev;
    }

    public function setIdPrev(int $id_prev): self
    {
        $this->id_prev = $id_prev;

        return $this;
    }

    public function getHistoriqueRelation(): ?ExpireAssets
    {
        return $this->historique_relation;
    }

    public function setHistoriqueRelation(?ExpireAssets $historique_relation): self
    {
        $this->historique_relation = $historique_relation;

        return $this;
    }
}
