<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ExpireAssetsRepository")
 */
class ExpireAssets
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $marque;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $domaine;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $editeur;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $logiciel;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $acheteur;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $reference_DA;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $demandeur;

    /**
     * @ORM\Column(type="text")
     */
    private $commentaire;

    /**
     * @ORM\Column(type="datetime")
     */
    private $date_expiration;

    /**
     * @ORM\Column(type="datetime")
     */
    private $date_relance;

    /**
     * @ORM\Column(type="boolean")
     */
    private $type_contrat;

    /**
     * @ORM\Column(type="datetime")
     */
    private $date_creation;

    /**
     * @ORM\Column(type="datetime")
     */
    private $date_maj;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $user_maj;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Nature")
     */
    private $nature_relation;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\User", mappedBy="user_Relation")
     */
    private $users;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Produit", mappedBy="produit_relation")
     */
    private $produits;

    public function __construct()
    {
        $this->users = new ArrayCollection();
        $this->produits = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getMarque(): ?string
    {
        return $this->marque;
    }

    public function setMarque(string $marque): self
    {
        $this->marque = $marque;

        return $this;
    }

    public function getDomaine(): ?string
    {
        return $this->domaine;
    }

    public function setDomaine(string $domaine): self
    {
        $this->domaine = $domaine;

        return $this;
    }

    public function getEditeur(): ?string
    {
        return $this->editeur;
    }

    public function setEditeur(string $editeur): self
    {
        $this->editeur = $editeur;

        return $this;
    }

    public function getLogiciel(): ?string
    {
        return $this->logiciel;
    }

    public function setLogiciel(string $logiciel): self
    {
        $this->logiciel = $logiciel;

        return $this;
    }

    public function getAcheteur(): ?string
    {
        return $this->acheteur;
    }

    public function setAcheteur(string $acheteur): self
    {
        $this->acheteur = $acheteur;

        return $this;
    }

    public function getReferenceDA(): ?string
    {
        return $this->reference_DA;
    }

    public function setReferenceDA(string $reference_DA): self
    {
        $this->reference_DA = $reference_DA;

        return $this;
    }

    public function getDemandeur(): ?string
    {
        return $this->demandeur;
    }

    public function setDemandeur(string $demandeur): self
    {
        $this->demandeur = $demandeur;

        return $this;
    }

    public function getCommentaire(): ?string
    {
        return $this->commentaire;
    }

    public function setCommentaire(string $commentaire): self
    {
        $this->commentaire = $commentaire;

        return $this;
    }

    public function getDateExpiration(): ?\DateTimeInterface
    {
        return $this->date_expiration;
    }

    public function setDateExpiration(\DateTimeInterface $date_expiration): self
    {
        $this->date_expiration = $date_expiration;

        return $this;
    }

    public function getDateRelance(): ?\DateTimeInterface
    {
        return $this->date_relance;
    }

    public function setDateRelance(\DateTimeInterface $date_relance): self
    {
        $this->date_relance = $date_relance;

        return $this;
    }

    public function getTypeContrat(): ?bool
    {
        return $this->type_contrat;
    }

    public function setTypeContrat(bool $type_contrat): self
    {
        $this->type_contrat = $type_contrat;

        return $this;
    }

    public function getDateCreation(): ?\DateTimeInterface
    {
        return $this->date_creation;
    }

    public function setDateCreation(\DateTimeInterface $date_creation): self
    {
        $this->date_creation = $date_creation;

        return $this;
    }

    public function getDateMaj(): ?\DateTimeInterface
    {
        return $this->date_maj;
    }

    public function setDateMaj(\DateTimeInterface $date_maj): self
    {
        $this->date_maj = $date_maj;

        return $this;
    }

    public function getUserMaj(): ?string
    {
        return $this->user_maj;
    }

    public function setUserMaj(string $user_maj): self
    {
        $this->user_maj = $user_maj;

        return $this;
    }

    public function getNatureRelation(): ?Nature
    {
        return $this->nature_relation;
    }

    public function setNatureRelation(?Nature $nature_relation): self
    {
        $this->nature_relation = $nature_relation;

        return $this;
    }

    /**
     * @return Collection|User[]
     */
    public function getUsers(): Collection
    {
        return $this->users;
    }

    public function addUser(User $user): self
    {
        if (!$this->users->contains($user)) {
            $this->users[] = $user;
            $user->addUserRelation($this);
        }

        return $this;
    }

    public function removeUser(User $user): self
    {
        if ($this->users->contains($user)) {
            $this->users->removeElement($user);
            $user->removeUserRelation($this);
        }

        return $this;
    }

    /**
     * @return Collection|Produit[]
     */
    public function getProduits(): Collection
    {
        return $this->produits;
    }

    public function addProduit(Produit $produit): self
    {
        if (!$this->produits->contains($produit)) {
            $this->produits[] = $produit;
            $produit->addProduitRelation($this);
        }

        return $this;
    }

    public function removeProduit(Produit $produit): self
    {
        if ($this->produits->contains($produit)) {
            $this->produits->removeElement($produit);
            $produit->removeProduitRelation($this);
        }

        return $this;
    }
}
