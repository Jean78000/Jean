<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\Collection;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass="App\Repository\RoleUserRepository")
 */
class RoleUser
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups("user:show")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups("user:show")
     */
    private $str_Role;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\User", mappedBy="roleUser")
     */
    private $role_user_relation;

    public function __construct()
    {
        $this->role_user_relation = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getStrRole(): ?string
    {
        return $this->str_Role;
    }

    public function setStrRole(string $str_Role): self
    {
        $this->str_Role = $str_Role;

        return $this;
    }

    /**
     * @return Collection|User[]
     */
    public function getRoleUserRelation(): Collection
    {
        return $this->role_user_relation;
    }

    public function addRoleUserRelation(User $roleUserRelation): self
    {
        if (!$this->role_user_relation->contains($roleUserRelation)) {
            $this->role_user_relation[] = $roleUserRelation;
            $roleUserRelation->setRoleUser($this);
        }

        return $this;
    }

    public function removeRoleUserRelation(User $roleUserRelation): self
    {
        if ($this->role_user_relation->contains($roleUserRelation)) {
            $this->role_user_relation->removeElement($roleUserRelation);
            // set the owning side to null (unless already changed)
            if ($roleUserRelation->getRoleUser() === $this) {
                $roleUserRelation->setRoleUser(null);
            }
        }

        return $this;
    }
}
