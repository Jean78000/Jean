<?php

namespace App\Controller;

use App\Entity\User;
use App\Repository\UserRepository;
use App\Repository\RoleUserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ApiUserController extends AbstractController {

    /**
     * @Route("/api/user", name="api_user_index", methods={"GET"})
     */
    
    public function index(UserRepository $userRepository) {

        return $this->json($userRepository->findAll(), 200, [], ['groups' => 'user:show']);
    }


    /**
    * @Route("/api/user", name="api_user_create", methods={"POST"})
    */

    public function create(Request $request, RoleUserRepository $roleUserRepo, SerializerInterface $serializer, EntityManagerInterface $em) {

        $jsonRecu = $request->getContent();

        $obj = json_decode($jsonRecu);
        $roleUser = $obj->roleUser;
        $roleUser = $roleUserRepo->find($roleUser);

        $user = $serializer->deserialize($jsonRecu, User::class, 'json');

        $user->setRoleUser($roleUser);
        $em->persist($user);
        $em->flush();

        return $this->json($user, 201, [], ['groups' => 'user:show']);
        
    }


    
}
