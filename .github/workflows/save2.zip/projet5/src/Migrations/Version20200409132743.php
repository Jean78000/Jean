<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200409132743 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE contact_commerciaux (id INT AUTO_INCREMENT NOT NULL, contact_commerciaux_relation_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, mail VARCHAR(255) NOT NULL, telephonne INT NOT NULL, INDEX IDX_4868DD3986DA6F17 (contact_commerciaux_relation_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE expire_assets (id INT AUTO_INCREMENT NOT NULL, nature_relation_id INT DEFAULT NULL, marque VARCHAR(255) NOT NULL, domaine VARCHAR(255) NOT NULL, editeur VARCHAR(255) NOT NULL, logiciel VARCHAR(255) NOT NULL, acheteur VARCHAR(255) NOT NULL, reference_da VARCHAR(255) NOT NULL, demandeur VARCHAR(255) NOT NULL, commentaire LONGTEXT NOT NULL, date_expiration DATETIME NOT NULL, date_relance DATETIME NOT NULL, type_contrat TINYINT(1) NOT NULL, date_creation DATETIME NOT NULL, date_maj DATETIME NOT NULL, user_maj VARCHAR(255) NOT NULL, INDEX IDX_B6EEA5735CD1E90F (nature_relation_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE historique (id INT AUTO_INCREMENT NOT NULL, historique_relation_id INT DEFAULT NULL, id_prev INT NOT NULL, UNIQUE INDEX UNIQ_EDBFD5ECEBF89F3D (historique_relation_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE nature (id INT AUTO_INCREMENT NOT NULL, str_nature VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE produit (id INT AUTO_INCREMENT NOT NULL, produit_nom VARCHAR(255) NOT NULL, product_owner VARCHAR(255) NOT NULL, filiere VARCHAR(255) NOT NULL, date_fin_support DATETIME NOT NULL, fournisseur VARCHAR(255) NOT NULL, version VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE produit_expire_assets (produit_id INT NOT NULL, expire_assets_id INT NOT NULL, INDEX IDX_98B003ADF347EFB (produit_id), INDEX IDX_98B003ADA434945C (expire_assets_id), PRIMARY KEY(produit_id, expire_assets_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE role_user (id INT AUTO_INCREMENT NOT NULL, str_role VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user (id INT AUTO_INCREMENT NOT NULL, role_user_id INT NOT NULL, badge VARCHAR(255) NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, INDEX IDX_8D93D6491BA3766E (role_user_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user_expire_assets (user_id INT NOT NULL, expire_assets_id INT NOT NULL, INDEX IDX_58600823A76ED395 (user_id), INDEX IDX_58600823A434945C (expire_assets_id), PRIMARY KEY(user_id, expire_assets_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE contact_commerciaux ADD CONSTRAINT FK_4868DD3986DA6F17 FOREIGN KEY (contact_commerciaux_relation_id) REFERENCES produit (id)');
        $this->addSql('ALTER TABLE expire_assets ADD CONSTRAINT FK_B6EEA5735CD1E90F FOREIGN KEY (nature_relation_id) REFERENCES nature (id)');
        $this->addSql('ALTER TABLE historique ADD CONSTRAINT FK_EDBFD5ECEBF89F3D FOREIGN KEY (historique_relation_id) REFERENCES expire_assets (id)');
        $this->addSql('ALTER TABLE produit_expire_assets ADD CONSTRAINT FK_98B003ADF347EFB FOREIGN KEY (produit_id) REFERENCES produit (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE produit_expire_assets ADD CONSTRAINT FK_98B003ADA434945C FOREIGN KEY (expire_assets_id) REFERENCES expire_assets (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE user ADD CONSTRAINT FK_8D93D6491BA3766E FOREIGN KEY (role_user_id) REFERENCES role_user (id)');
        $this->addSql('ALTER TABLE user_expire_assets ADD CONSTRAINT FK_58600823A76ED395 FOREIGN KEY (user_id) REFERENCES user (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE user_expire_assets ADD CONSTRAINT FK_58600823A434945C FOREIGN KEY (expire_assets_id) REFERENCES expire_assets (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE historique DROP FOREIGN KEY FK_EDBFD5ECEBF89F3D');
        $this->addSql('ALTER TABLE produit_expire_assets DROP FOREIGN KEY FK_98B003ADA434945C');
        $this->addSql('ALTER TABLE user_expire_assets DROP FOREIGN KEY FK_58600823A434945C');
        $this->addSql('ALTER TABLE expire_assets DROP FOREIGN KEY FK_B6EEA5735CD1E90F');
        $this->addSql('ALTER TABLE contact_commerciaux DROP FOREIGN KEY FK_4868DD3986DA6F17');
        $this->addSql('ALTER TABLE produit_expire_assets DROP FOREIGN KEY FK_98B003ADF347EFB');
        $this->addSql('ALTER TABLE user DROP FOREIGN KEY FK_8D93D6491BA3766E');
        $this->addSql('ALTER TABLE user_expire_assets DROP FOREIGN KEY FK_58600823A76ED395');
        $this->addSql('DROP TABLE contact_commerciaux');
        $this->addSql('DROP TABLE expire_assets');
        $this->addSql('DROP TABLE historique');
        $this->addSql('DROP TABLE nature');
        $this->addSql('DROP TABLE produit');
        $this->addSql('DROP TABLE produit_expire_assets');
        $this->addSql('DROP TABLE role_user');
        $this->addSql('DROP TABLE user');
        $this->addSql('DROP TABLE user_expire_assets');
    }
}
