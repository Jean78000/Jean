<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\NatureRepository")
 */
class Nature
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $str_Nature;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getStrNature(): ?string
    {
        return $this->str_Nature;
    }

    public function setStrNature(string $str_Nature): self
    {
        $this->str_Nature = $str_Nature;

        return $this;
    }
}
