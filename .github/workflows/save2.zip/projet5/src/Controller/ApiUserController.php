<?php

namespace App\Controller;

use App\Repository\UserRepository;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

class ApiUserController extends AbstractController
{
    /**
     * @Route("/api/user", name="api_user_index", methods={"GET"})
     */
    public function index(UserRepository $userRepository, NormalizerInterface $normalizer) {

        $users = $userRepository->findAll();

        $usersNormalises = $normalizer->normalize($users, null, ['groups' => 'user:show']);

        dd($usersNormalises);

        $json = json_encode($users);
        dd($json, $users);
        return $this->render('api_user/index.html.twig', [
            'controller_name' => 'ApiUserController',
        ]);
    }
}
